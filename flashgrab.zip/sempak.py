from cgitb import text
from flask import Flask, render_template, request, redirect, url_for, Response
from bs4 import BeautifulSoup
import requests
import random
import datetime
from datetime import date, datetime, timedelta
from random import randint
from time import sleep
from os import unlink, remove
import os
timers = datetime.now()

# Sok Atuh Setingnya di sini....
namasite = "MY SITEEEEEEEEEEEEEEEEEEE"
histats = ""
link_offer = "https://www.google.com"
author = "Hilman"
deskripsi = "Festifal"
data4 = timers.strftime("%A"+". "+"%d "+"%B "+"%Y")

app = Flask(__name__)
d3 = datetime.utcnow() + timedelta(days=randint(-40, 1))
d4 = d3.strftime("%Y-%m-%dT%H:%M:%S+00:00")


@app.route("/")
def hello_world():
    d3 = datetime.utcnow() + timedelta()
    d4 = d3.strftime("%Y-%m-%d")
    c = requests.session()

    r = c.get('https://www.setlist.fm/search?query=date:'+d4)
    soup = BeautifulSoup(r.text, "html.parser")

    taiku = soup.find(
        'ul', class_="listPagingNavigator text-center hidden-print")
    taimu = taiku.find('a').text
    nextcrit = "2"
    return render_template('index.html', soup=soup, dt4=data4, nextcrit=nextcrit,
                           namasite=namasite, link_offer=link_offer, histats=histats, author=author,
                           deskripsi=deskripsi)


@app.route("/p/<id>.html")
def next_page(id):
    d3 = datetime.utcnow() + timedelta()
    d4 = d3.strftime("%Y-%m-%d")
    c = requests.session()
    namasite = "MY SITEEEEEE"
    r = c.get('https://www.setlist.fm/search?page=' + id + '&query=date:'+d4)
    soup = BeautifulSoup(r.text, "html.parser")
    nextcrit = int(id)+1
    nextcrot = int(id)-1
    taiku = soup.find(
        "ul", class_="listPagingNavigator text-center hidden-print")
    taimu = taiku.find('a').text
    return render_template('index.html', soup=soup, dt4=data4, nextpage=taimu, id=id, nextcrit=nextcrit, nextcrot=nextcrot, pep=id,
                           namasite=namasite, link_offer=link_offer, histats=histats, author=author,
                           deskripsi=deskripsi)


@app.route("/reg.html")
def reg():
    return render_template('live.html', link_offer=link_offer)


@app.route("/dmca")
@app.route("/dmca/")
def dmca():
    return render_template('dmca.html')


@app.route("/contact")
@app.route("/contact/")
def contact():
    return render_template('contact.html')


@app.route("/disclaimer")
@app.route("/disclaimer/")
def disclaimer():
    return render_template('disclaimer.html')


@app.route("/feed")
@app.route("/feed/")
def feed():
    taek = request.base_url
    taek1 = taek.replace('index-sitemap.xml', '')
    file = open('keyword/1.txt', 'r')
    randm = file.readlines()

    #brodol = random.choice(randm)
    # return render_template('sitemap-index.xml',taek=taek1, filess=filess, mimetype='text/xml')
    # return render_template('feed.xml',taek=taek1, mimetype='text/xml')
    r = Response(response=render_template("feed.xml", status=200,
                 mimetype="text/xml", dt4=d4, taek=taek1, brodol=randm))
    r.headers["Content-Type"] = "text/xml; charset=utf-8"
    return r

# @app.route("/<posting>.html")
# def content(posting):


@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def catch_all(path):
    author = "Hilman"
    deskripsi = "Concert, Concerts"
    baseurl = request.base_url

    d3 = datetime.utcnow() + timedelta()
    d4 = d3.strftime("%Y-%m-%d")
    c = requests.session()
    namasite = "MY SITEEEEEEEEEEEEEEEEEEE"
    url1 = request.base_url
    url2 = url1.replace(request.url_root, 'https://www.setlist.fm/')
    r = c.get(url2)
    soup = BeautifulSoup(r.text, "html.parser")
    try:
        tai = soup.find('h1',)
        #judul = tai.find('strong')
        judul = tai.find_all('span')[1].text
        venue = tai.find_all('span')[4].text
        venuecrit = venue.split(',')[0]
    except:
        print("crot")
        pass
    try:
        taik = soup.find('div', class_='infoContainer')
        tour = "TOUR : "+taik.find('p').find('a').text
    except:
        print("crot")
        pass
    #dul = jud.split(',')
    #judul = dul[0]
    #judul = str(judul).replace('Setlist','')
    #kon2 = str(dul[1])
    #jem = str(jud).split('at')
    #artis = jem[0].replace('Setlist','')

    # return render_template('post.html', soup = soup, dt4=data4,namasite=namasite,link_offer=link_offer,\
    #    histats=histats,author=author, deskripsi=deskripsi,judul=judul)
    try:
        return render_template('post.html', soup=soup, dt4=data4, namasite=namasite, link_offer=link_offer,
                               histats=histats, author=author, deskripsi=deskripsi, judul=judul, venue=str(venue), venuecrit=str(venuecrit), tour=str(tour))
    except:
        return render_template('post.html', soup=soup, dt4=data4, namasite=namasite, link_offer=link_offer,
                               histats=histats, author=author, deskripsi=deskripsi, judul=judul, venue=str(venue), venuecrit=str(venuecrit))


@app.route("/index-sitemap.xml")
def sitemap_index():
    path = 'keyword'
    filess = os.listdir(path)

    taek = request.base_url
    taek1 = taek.replace('index-sitemap.xml', '')
    # file = open('keyword/#.txt', 'r')
    #brodol = file.readlines()
    # return render_template('sitemap-index.xml',taek=taek1, filess=filess, mimetype='text/xml')
    r = Response(response=render_template("sitemap-index.xml", status=200,
                 mimetype="application/xml", d4=d4, taek=taek1, filess=filess))
    r.headers["Content-Type"] = "text/xml; charset=utf-8"
    return r


@app.route("/map-url-<int:filenya>.xml")
def sitemap_url(filenya):
    path = 'keyword'
    filess = os.listdir(path)

    taek = request.base_url
    taek1 = taek.replace('map-url-'+str(filenya), '').replace('.xml', '')
    file = open('keyword/' + str(filenya) + '.txt', 'r')
    brodol = file.readlines()
    # return render_template('sitemap-url.xml',taek=taek1, brodol=brodol)
    r = Response(response=render_template('sitemap-url.xml', taek=taek1,
                 brodol=brodol, status=200, d4=d4, mimetype="application/xml"))
    r.headers["Content-Type"] = "text/xml; charset=utf-8"
    return r


@app.route("/static/sitemap.xsl")
def sitemap_xsl():
    return render_template('sitemap.xsl')


if __name__ == "__main__":
    app.run(debug=True, port=3467)

# Repl
# if __name__ == "__main__":  # Makes sure this is the main process
#	app.run( # Starts the site
#		host='0.0.0.0',  # EStablishes the host, required for repl to detect the site
#		port=random.randint(2000, 9000)  # Randomly select the port the machine hosts on.
#	)
